#!/bin/bash
source ./venv/bin/activate
python app.py
snntoolbox ann-to-snn.ini -t