# ANN to SNN
